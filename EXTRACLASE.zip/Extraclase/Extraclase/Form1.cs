﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Extraclase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
           
            {
                InitializeComponent();

               

                // Crear la tabla de datos
                DataTable table = new DataTable();

                // Agregar las columnas a la tabla
                table.Columns.Add("Trimestre", typeof(string));
                table.Columns.Add("agua", typeof(int));
                table.Columns.Add("Luz", typeof(int));
                table.Columns.Add("Gas", typeof(int));

                // Agregar las filas a la tabla con los datos de gastos trimestrales
                table.Rows.Add("Trimestre1", 120, 85, 180);
                table.Rows.Add("Trimestre2", 420, 105, 225);
                table.Rows.Add("Trimestre3", 360, 90, 160);

                // Crear el control DataGridView
                DataGridView dataGridView = new DataGridView();
                dataGridView.Dock = DockStyle.Fill;
                dataGridView.AutoGenerateColumns = true;
                dataGridView.DataSource = table;

                // Agregar el control DataGridView al formulario
                Controls.Add(dataGridView);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    
}
